﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using mvc.sportsite.Models;

namespace mvc.sportsite.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>, IApplicationDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Equipment> Equipments { get; set; }
        public DbSet<RentalOrder> RentalOrders { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Equipment>()
                .Property(e => e.PricePerHour)
                .HasPrecision(18, 2)
                .HasColumnType("decimal(18,2)");

            builder.Entity<RentalOrder>()
                .HasOne(o => o.Equipment)
                .WithMany()
                .HasForeignKey(o => o.EquipmentId)
                .OnDelete(DeleteBehavior.Restrict);
        }
    }
}
﻿using Microsoft.EntityFrameworkCore;
using mvc.sportsite.Models;
using System.Threading;
using System.Threading.Tasks;

namespace mvc.sportsite.Data
{
    public interface IApplicationDbContext
    {
        DbSet<Equipment> Equipments { get; set; }
        DbSet<RentalOrder> RentalOrders { get; set; }

        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    }
}
﻿using Microsoft.AspNetCore.Identity;
using mvc.sportsite.Data;
using Microsoft.EntityFrameworkCore;

namespace mvc.sportsite.Models
{
    public static class SeedData
    {
        public static async Task Initialize(ApplicationDbContext context,
           UserManager<ApplicationUser> userManager,
           RoleManager<IdentityRole> roleManager)
        {
            if (context.Database.GetPendingMigrations().Any())
            {
                await context.Database.MigrateAsync();
            }

            string[] roles = { "Admin", "User" };

            foreach (var role in roles)
            {
                if (!await roleManager.RoleExistsAsync(role))
                {
                    await roleManager.CreateAsync(new IdentityRole(role));
                }
            }

            if (await userManager.FindByEmailAsync("admin@sportsite.com") == null)
            {
                var admin = new ApplicationUser
                {
                    UserName = "admin@sportsite.com",
                    Email = "admin@sportsite.com",
                    FullName = "Admin User",
                    EmailConfirmed = true
                };

                var result = await userManager.CreateAsync(admin, "Admin@123");
                if (result.Succeeded)
                {
                    await userManager.AddToRoleAsync(admin, "Admin");
                }
            }

            if (!context.Equipments.Any())
            {
                context.Equipments.AddRange(
                    new Equipment
                    {
                        Name = "Tennis Racket",
                        Type = "Tennis",
                        PricePerHour = 1500.50m,
                        IsAvailable = true,
                        ImageUrl = "/images/tennis-racket.jpg"
                    },
                    new Equipment
                    {
                        Name = "Mountain Bike",
                        Type = "Cycling",
                        PricePerHour = 3000.00m,
                        IsAvailable = true,
                        ImageUrl = "/images/mountain-bike.jpg"
                    },
                    new Equipment
                    {
                        Name = "Football",
                        Type = "Football",
                        PricePerHour = 500.00m,
                        IsAvailable = true,
                        ImageUrl = "/images/football.jpg"
                    }
                );
                await context.SaveChangesAsync();
            }
        }
    }
}
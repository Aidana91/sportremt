﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace mvc.sportsite.Models
{
    public class RentalOrder
    {
        public int Id { get; set; }

        [Required]
        public string UserId { get; set; }

        [ForeignKey("Equipment")]
        public int EquipmentId { get; set; }

        public Equipment Equipment { get; set; }

        [Required]
        [Display(Name = "Дата начала аренды")]
        public DateTime RentalStart { get; set; }

        [Required]
        [Display(Name = "Дата окончания аренды")]
        public DateTime RentalEnd { get; set; }

        [Display(Name = "Статус заказа")]
        public string Status { get; set; } // Pending, Confirmed, Cancelled
    }
}

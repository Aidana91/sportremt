﻿using System.ComponentModel.DataAnnotations;

namespace mvc.sportsite.Models
{
    public class Equipment
    {
        public int Id { get; set; }

        [Required]
        [Display(Name = "Название инвентаря")]
        public string Name { get; set; }

        [Required]
        [Display(Name = "Тип")]
        public string Type { get; set; }

        [Required]
        [Display(Name = "Цена в час (₸)")]
        [Range(0, double.MaxValue)]
        public decimal PricePerHour { get; set; }

        [Display(Name = "Доступен для аренды")]
        public bool IsAvailable { get; set; }

        [Display(Name = "Изображение")]
        public string ImageUrl { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using mvc.sportsite.Data;
using mvc.sportsite.Models;
using System.Security.Claims;

namespace mvc.sportsite.Controllers
{
    [Authorize]
    public class RentalController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RentalController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Оформление аренды
        [HttpGet]
        public async Task<IActionResult> Rent(int equipmentId)
        {
            var equipment = await _context.Equipments.FindAsync(equipmentId);
            if (equipment == null || !equipment.IsAvailable)
                return NotFound();

            ViewBag.Equipment = equipment;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Rent(int equipmentId, DateTime rentalStart, DateTime rentalEnd)
        {
            if (rentalStart >= rentalEnd || rentalStart < DateTime.Today)
            {
                ModelState.AddModelError("", "Неверные даты аренды.");
                return View();
            }

            var order = new RentalOrder
            {
                UserId = User.FindFirstValue(ClaimTypes.NameIdentifier),
                EquipmentId = equipmentId,
                RentalStart = rentalStart,
                RentalEnd = rentalEnd,
                Status = "Pending"
            };

            _context.RentalOrders.Add(order);
            await _context.SaveChangesAsync();

            return RedirectToAction("MyOrders");
        }

        // Просмотр заказов пользователя
        public async Task<IActionResult> MyOrders()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var orders = await _context.RentalOrders
                .Include(r => r.Equipment)
                .Where(r => r.UserId == userId)
                .ToListAsync();

            return View(orders);
        }
    }
}

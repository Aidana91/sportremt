﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using mvc.sportsite.Data;
using mvc.sportsite.Models;

namespace mvc.sportsite.Controllers
{
    [Authorize(Roles = "Admin")]

    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Панель администратора — список всего инвентаря
        public async Task<IActionResult> EquipmentList()
        {
            return View(await _context.Equipments.ToListAsync());
        }

        // Добавление нового инвентаря
        [HttpGet]
        public IActionResult AddEquipment()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddEquipment(Equipment equipment)
        {
            if (ModelState.IsValid)
            {
                equipment.IsAvailable = true;
                _context.Equipments.Add(equipment);
                await _context.SaveChangesAsync();
                return RedirectToAction("EquipmentList");
            }
            return View(equipment);
        }

        // Редактирование инвентаря
        [HttpGet]
        public async Task<IActionResult> EditEquipment(int id)
        {
            var equipment = await _context.Equipments.FindAsync(id);
            if (equipment == null) return NotFound();
            return View(equipment);
        }

        [HttpPost]
        public async Task<IActionResult> EditEquipment(Equipment equipment)
        {
            if (ModelState.IsValid)
            {
                _context.Equipments.Update(equipment);
                await _context.SaveChangesAsync();
                return RedirectToAction("EquipmentList");
            }
            return View(equipment);
        }

        // Удаление инвентаря
        public async Task<IActionResult> DeleteEquipment(int id)
        {
            var item = await _context.Equipments.FindAsync(id);
            if (item != null)
            {
                _context.Equipments.Remove(item);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("EquipmentList");
        }

        // Управление заявками на аренду
        public async Task<IActionResult> Orders()
        {
            var orders = await _context.RentalOrders
                .Include(o => o.Equipment)
                .Include(o => o.Equipment)
                .ToListAsync();
            return View(orders);
        }

        // Изменение статуса заказа
        [HttpPost]
        public async Task<IActionResult> UpdateOrderStatus(int id, string status)
        {
            var order = await _context.RentalOrders.FindAsync(id);
            if (order != null)
            {
                order.Status = status;
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Orders");
        }
    }
}

﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using mvc.sportsite.Data;

namespace mvc.sportsite.Controllers
{
    public class EquipmentController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EquipmentController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Список инвентаря с фильтрацией
        public async Task<IActionResult> Index(string type, string searchString)
        {
            var items = from e in _context.Equipments
                        where e.IsAvailable
                        select e;

            if (!string.IsNullOrEmpty(type))
                items = items.Where(x => x.Type.Contains(type));

            if (!string.IsNullOrEmpty(searchString))
                items = items.Where(x => x.Name.Contains(searchString));

            return View(await items.ToListAsync());
        }

        // Подробности об инвентаре
        public async Task<IActionResult> Details(int id)
        {
            var item = await _context.Equipments.FindAsync(id);
            if (item == null || !item.IsAvailable)
                return NotFound();

            return View(item);
        }
    }
}
